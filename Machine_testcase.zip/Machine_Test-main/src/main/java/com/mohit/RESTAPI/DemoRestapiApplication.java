package com.mohit.RESTAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoRestapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoRestapiApplication.class, args);
	}

}
